# 3x-ui trên Railway — Single Port (không cần TCP Proxy)

Chạy **3x-ui** kèm **nginx reverse proxy** trên Railway, gộp toàn bộ traffic (web panel + VLESS/WS inbound) vào **một cổng duy nhất** mà Railway cấp.

---

## Cấu trúc dự án

```
├── Dockerfile            # Build image Alpine + nginx + 3x-ui
├── nginx.conf.template   # Template nginx (APP_PORT được điền lúc runtime)
├── start.sh              # Script khởi động
├── railway.toml          # Cấu hình Railway
└── README.md
```

---

## Deploy lên Railway

### 1. Tạo repository GitHub

Tạo repo mới (public hoặc private) và push 4 file trên vào thư mục gốc.

### 2. Tạo project Railway

1. Vào [railway.app](https://railway.app) → **New Project → Deploy from GitHub repo**
2. Chọn repo vừa tạo
3. Railway tự detect `Dockerfile` và build
4. Sau khi deploy xong → **Settings → Networking → Generate Domain**

> Railway tự inject biến `$PORT`. Không cần set thủ công.

### 3. Đăng nhập panel

```
https://your-domain.up.railway.app/managepanel/
```

- Username mặc định: `admin`
- Password mặc định: `admin`
- **Đổi ngay sau khi đăng nhập!**

### 4. Tạo Inbound

| Trường       | Giá trị                              |
|--------------|--------------------------------------|
| Protocol     | VLESS                                |
| Listen Port  | **8080** (không đổi)                 |
| Listen IP    | để trống hoặc `0.0.0.0`             |
| Network      | ws                                   |
| Security     | none                                 |
| Path         | ví dụ `/cdn` hoặc tùy chọn          |

> ⚠️ Port inbound phải là **8080** vì nginx proxy đến `127.0.0.1:8080`.  
> Nếu muốn đổi port khác, sửa tương ứng trong `nginx.conf.template` rồi redeploy.

### 5. Link kết nối client

```
vless://UUID@your-domain.up.railway.app:443?encryption=none&security=tls&sni=your-domain.up.railway.app&fp=chrome&type=ws&host=your-domain.up.railway.app&path=%2Fcdn#MyConfig
```

Thay `UUID`, `your-domain`, và `path` bằng giá trị thực.

---

## Kiểm tra nhanh

| URL | Kết quả mong đợi |
|-----|-----------------|
| `https://domain/health` | `ok` |
| `https://domain/managepanel/` | Trang đăng nhập 3x-ui |
| `https://domain/cdn` | `Bad Request` (nghĩa là Xray nhận được) |

---

## Lưu dữ liệu (tránh mất khi redeploy)

Railway xóa filesystem mỗi lần redeploy. Để giữ cấu hình, inbound và user:

1. Railway dashboard → project → **+ Add Volume**
2. Mount path: `/etc/x-ui`

---

## Luồng traffic

```
Client (HTTPS :443)
    │
    ▼
Railway TLS Termination
    │
    ▼
nginx (port $PORT)
    ├─ /managepanel/*  →  x-ui panel   (127.0.0.1:2053)
    ├─ /sub/*          →  subscription (127.0.0.1:2096)
    ├─ /health         →  200 ok
    └─ /*              →  xray inbound (127.0.0.1:8080)
```
